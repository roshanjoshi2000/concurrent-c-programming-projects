#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

/*
    Structure used to pass data to each thread.
    Each thread needs to know:
    - where to start
    - where to end
    - where to store its partial sum
*/
typedef struct {
    long long start;
    long long end;
    double partial_sum;
} ThreadData;

/*
    Thread function.
    This calculates part of the Leibniz series.

    Leibniz formula:
    pi = 4 * (1 - 1/3 + 1/5 - 1/7 + 1/9 - ...)
*/
void *calculate_pi_part(void *arg) {
    ThreadData *data = (ThreadData *)arg;

    double sum = 0.0;

    for (long long i = data->start; i < data->end; i++) {
        double term;

        if (i % 2 == 0) {
            term = 1.0 / (2.0 * i + 1.0);
        } else {
            term = -1.0 / (2.0 * i + 1.0);
        }

        sum += term;
    }

    data->partial_sum = sum;

    return NULL;
}

int main(int argc, char *argv[]) {
    long long iterations;
    int thread_count;

    pthread_t *threads;
    ThreadData *thread_data;

    double total_sum = 0.0;
    double pi;

    /*
        Check command-line arguments.
        argv[1] = number of iterations
        argv[2] = number of threads
    */
    if (argc != 3) {
        printf("Usage: %s <number_of_iterations> <number_of_threads>\n", argv[0]);
        return 1;
    }

    iterations = atoll(argv[1]);
    thread_count = atoi(argv[2]);

    if (iterations <= 0) {
        printf("Error: Number of iterations must be greater than 0.\n");
        return 1;
    }

    if (thread_count <= 0) {
        printf("Error: Number of threads must be greater than 0.\n");
        return 1;
    }

    /*
        If the user asks for more threads than iterations,
        reduce the thread count so no thread gets useless work.
    */
    if (thread_count > iterations) {
        thread_count = (int)iterations;
    }

    /*
        Allocate memory dynamically for threads and thread data.
    */
    threads = malloc(thread_count * sizeof(pthread_t));
    thread_data = malloc(thread_count * sizeof(ThreadData));

    if (threads == NULL || thread_data == NULL) {
        printf("Error: Memory allocation failed.\n");
        free(threads);
        free(thread_data);
        return 1;
    }

    /*
        Dynamic workload slicing.

        Example:
        iterations = 10, threads = 3

        base_work = 10 / 3 = 3
        extra_work = 10 % 3 = 1

        Thread 0 gets 4 iterations
        Thread 1 gets 3 iterations
        Thread 2 gets 3 iterations

        This keeps the work equal or almost equal.
    */
    long long base_work = iterations / thread_count;
    long long extra_work = iterations % thread_count;

    long long current_start = 0;

    for (int i = 0; i < thread_count; i++) {
        long long work_for_this_thread = base_work;

        if (i < extra_work) {
            work_for_this_thread++;
        }

        thread_data[i].start = current_start;
        thread_data[i].end = current_start + work_for_this_thread;
        thread_data[i].partial_sum = 0.0;

        current_start = thread_data[i].end;

        if (pthread_create(&threads[i], NULL, calculate_pi_part, &thread_data[i]) != 0) {
            printf("Error: Could not create thread %d.\n", i);
            free(threads);
            free(thread_data);
            return 1;
        }
    }

    /*
        Wait for all threads to finish.
    */
    for (int i = 0; i < thread_count; i++) {
        pthread_join(threads[i], NULL);
    }

    /*
        Combine all partial sums.
    */
    for (int i = 0; i < thread_count; i++) {
        total_sum += thread_data[i].partial_sum;
    }

    pi = 4.0 * total_sum;

    printf("\nLeibniz Pi Calculation\n");
    printf("----------------------\n");
    printf("Iterations: %lld\n", iterations);
    printf("Threads used: %d\n", thread_count);
    printf("Calculated Pi: %.15f\n", pi);

    free(threads);
    free(thread_data);

    return 0;
}
