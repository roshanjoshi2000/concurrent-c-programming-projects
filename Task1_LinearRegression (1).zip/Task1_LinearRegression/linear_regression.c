#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    FILE *file;

    double x, y;
    double sumX = 0.0;
    double sumY = 0.0;
    double sumXY = 0.0;
    double sumX2 = 0.0;

    int n = 0;

    double b, a;
    double denominator;
    double userX, predictedY;

    if (argc != 2) {
        printf("Usage: %s <data_file>\n", argv[0]);
        return 1;
    }

    file = fopen(argv[1], "r");

    if (file == NULL) {
        printf("Error: Could not open file '%s'.\n", argv[1]);
        return 1;
    }

    while (fscanf(file, "%lf,%lf", &x, &y) == 2) {
        sumX += x;
        sumY += y;
        sumXY += x * y;
        sumX2 += x * x;
        n++;
    }

    fclose(file);

    if (n < 2) {
        printf("Error: The file must contain at least two coordinate pairs.\n");
        return 1;
    }

    denominator = (n * sumX2) - (sumX * sumX);

    if (denominator == 0) {
        printf("Error: Cannot calculate linear regression because denominator is zero.\n");
        printf("This may happen if all x values are the same.\n");
        return 1;
    }

    b = ((n * sumXY) - (sumX * sumY)) / denominator;
    a = (sumY - (b * sumX)) / n;

    printf("\nLinear Regression Results\n");
    printf("-------------------------\n");
    printf("Number of points: %d\n", n);
    printf("Gradient b: %.6lf\n", b);
    printf("Constant a: %.6lf\n", a);

    if (a >= 0) {
        printf("Equation: y = %.6lfx + %.6lf\n", b, a);
    } else {
        printf("Equation: y = %.6lfx - %.6lf\n", b, -a);
    }

    printf("\nEnter a value for x: ");

    if (scanf("%lf", &userX) != 1) {
        printf("Error: Invalid input for x.\n");
        return 1;
    }

    predictedY = (b * userX) + a;

    printf("Predicted y value: %.6lf\n", predictedY);

    return 0;
}
